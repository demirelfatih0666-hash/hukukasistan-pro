import 'package:firebase_ai/firebase_ai.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

const navy = Color(0xFF071B36);
const gold = Color(0xFFD8B33E);
const adminEmail = 'demirel.fatih0666@gmail.com';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const HukukAsistanApp());
}

class HukukAsistanApp extends StatelessWidget {
  const HukukAsistanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'HukukAsistan AI',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark), scaffoldBackgroundColor: navy, appBarTheme: const AppBarTheme(backgroundColor: navy), inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), filled: true), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final actions = <(String, IconData, Widget)>[
      ('Hukuk AI', Icons.auto_awesome, const HukukAiPage()),
      ('Dilekçe Oluştur', Icons.description, const PetitionPage()),
      ('Yargıtay Kararları', Icons.gavel, const OfficialSourcesPage(decisions: true)),
      ('Güncel Mevzuat', Icons.account_balance, const OfficialSourcesPage(decisions: false)),
      ('Yönetici Paneli', Icons.admin_panel_settings, const AdminLoginPage()),
    ];
    return Scaffold(appBar: AppBar(title: const Text('HukukAsistan AI')), body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Hukuki bilgiye akıllı erişim', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Sorunuzu sorun, dilekçe taslağı hazırlayın ve resmî kaynaklarla doğrulayın.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 18),
      ...actions.map(
        (e) => Card(
          color: const Color(0xFF102B50),
          child: ListTile(
            contentPadding: const EdgeInsets.all(15),
            leading: CircleAvatar(
              backgroundColor: gold,
              foregroundColor: navy,
              child: Icon(e.$2),
            ),
            title: Text(
              e.$1,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => e.$3),
            ),
          ),
        ),
      ),
      const Padding(padding: EdgeInsets.only(top: 12), child: Text('Uyarı: Yapay zekâ yanıtları hukuki danışmanlık değildir. Süre veya hak kaybı riski bulunan işlemlerde avukata danışın.', style: TextStyle(fontSize: 12, color: Colors.white60))),
    ]));
  }
}

class HukukAiPage extends StatefulWidget {
  const HukukAiPage({super.key});
  @override
  State<HukukAiPage> createState() => _HukukAiPageState();
}

class _HukukAiPageState extends State<HukukAiPage> {
  final controller = TextEditingController();
  final source = TextEditingController();
  String answer = '';
  bool loading = false;
  Future<void> ask() async {
    final question = controller.text.trim();
    final sourceText = source.text.trim();
    if (question.isEmpty || sourceText.isEmpty) {
      setState(() => answer = 'Doğrulanmış kaynak bulunamadı. Önce resmî karar veya mevzuat metnini kaynak alanına yapıştırın.');
      return;
    }
    setState(() { loading = true; answer = ''; });
    try {
      final model = FirebaseAI.googleAI().generativeModel(model: 'gemini-3.8-flash');
      final prompt = '''Sen Türkiye hukuku için kaynak denetimli HukukAsistan AI'sın. Yalnızca aşağıdaki RESMÎ KAYNAK METNİNDE açıkça bulunan bilgilere dayan. Kaynakta bulunmayan kanun maddesi, karar numarası, tarih, taraf, gerekçe veya hukuki sonuç ekleme. Kaynak soruyu cevaplamaya yetmiyorsa sadece "Bu soruyu doğrulamak için kaynak metin yeterli değil." yaz. Yanıtın sonunda "Dayanak:" başlığıyla kullandığın kaynak bölümlerini kısa biçimde belirt. Bunun hukuki danışmanlık olmadığını hatırlat.

SORU:
$question

RESMÎ KAYNAK METNİ:
$sourceText''';
      final response = await model.generateContent([Content.text(prompt)]);
      setState(() => answer = response.text ?? 'Yanıt üretilemedi.');
    } catch (e) {
      setState(() => answer = 'Bağlantı kurulamadı. Firebase AI Logic ve internet bağlantısını kontrol edin.\n\nHata: $e');
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Hukuk AI')), body: ListView(padding: const EdgeInsets.all(18), children: [
    TextField(controller: controller, minLines: 2, maxLines: 5, decoration: const InputDecoration(labelText: 'Hukuki sorunuzu yazın')),
    const SizedBox(height: 12),
    TextField(controller: source, minLines: 6, maxLines: 14, decoration: const InputDecoration(labelText: 'Resmî kaynak metni (zorunlu)', hintText: 'UYAP/Yargıtay kararı veya mevzuat metnini buraya yapıştırın')),
    const SizedBox(height: 12), FilledButton.icon(onPressed: loading ? null : ask, icon: const Icon(Icons.auto_awesome), label: Text(loading ? 'Yanıt hazırlanıyor...' : 'Hukuk AI’ya Sor')),
    if (loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
    if (answer.isNotEmpty) Card(color: const Color(0xFF102B50), child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(answer, style: const TextStyle(fontSize: 16, height: 1.45)))),
  ]));
}

class PetitionPage extends StatefulWidget {
  const PetitionPage({super.key});
  @override
  State<PetitionPage> createState() => _PetitionPageState();
}
class _PetitionPageState extends State<PetitionPage> {
  final court = TextEditingController(), subject = TextEditingController(), facts = TextEditingController();
  String draft = '';
  void create() => setState(() => draft = '''${court.text.trim().isEmpty ? 'İLGİLİ MAKAMA' : court.text.trim().toUpperCase()}

KONU: ${subject.text.trim()}

AÇIKLAMALAR:
${facts.text.trim()}

SONUÇ VE TALEP:
Yukarıda açıklanan nedenlerle gereğinin yapılmasını saygılarımla arz ederim.

Tarih:
Ad Soyad:
İmza:

Not: Bu metin taslaktır; hukuki ve kişisel bilgiler kontrol edilmelidir.''');
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Dilekçe Oluştur')), body: ListView(padding: const EdgeInsets.all(18), children: [
    TextField(controller: court, decoration: const InputDecoration(labelText: 'Makam / Mahkeme')), const SizedBox(height: 10),
    TextField(controller: subject, decoration: const InputDecoration(labelText: 'Konu')), const SizedBox(height: 10),
    TextField(controller: facts, minLines: 5, maxLines: 10, decoration: const InputDecoration(labelText: 'Olaylar ve talep')), const SizedBox(height: 12),
    FilledButton.icon(onPressed: create, icon: const Icon(Icons.description), label: const Text('Taslak Oluştur')),
    if (draft.isNotEmpty) Card(color: const Color(0xFF102B50), child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(draft))),
  ]));
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});
  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}
class _AdminLoginPageState extends State<AdminLoginPage> {
  final email = TextEditingController(text: adminEmail), password = TextEditingController();
  String error = '';
  bool loading = false;
  Future<void> login() async {
    if (email.text.trim().toLowerCase() != adminEmail) { setState(() => error = 'Bu hesap yönetici olarak yetkili değil.'); return; }
    setState(() { loading = true; error = ''; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminPanel()));
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.code == 'invalid-credential' ? 'E-posta veya şifre hatalı.' : 'Giriş yapılamadı: ${e.code}');
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Yönetici Girişi')), body: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.admin_panel_settings, size: 72, color: gold), const SizedBox(height: 20),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Yönetici e-postası')), const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Şifre')),
    if (error.isNotEmpty) Padding(padding: const EdgeInsets.all(10), child: Text(error, style: const TextStyle(color: Colors.redAccent))),
    FilledButton.icon(onPressed: loading ? null : login, icon: const Icon(Icons.login), label: Text(loading ? 'Giriş yapılıyor...' : 'Giriş Yap')),
  ])));
}

class AdminPanel extends StatelessWidget {
  const AdminPanel({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Yönetici Paneli'), actions: [IconButton(onPressed: () async { await FirebaseAuth.instance.signOut(); if (context.mounted) Navigator.pop(context); }, icon: const Icon(Icons.logout))]), body: ListView(padding: const EdgeInsets.all(18), children: const [
    Card(color: Color(0xFF102B50), child: ListTile(leading: Icon(Icons.verified_user, color: gold), title: Text('Yönetici hesabı aktif'), subtitle: Text(adminEmail))),
    Card(color: Color(0xFF102B50), child: ListTile(leading: Icon(Icons.campaign, color: gold), title: Text('Duyuru Yönetimi'), subtitle: Text('Duyuru ekleme ve düzenleme altyapısı'))),
    Card(color: Color(0xFF102B50), child: ListTile(leading: Icon(Icons.description, color: gold), title: Text('Dilekçe Şablonları'), subtitle: Text('Şablon yönetimi altyapısı'))),
  ]));
}

class OfficialSourcesPage extends StatelessWidget {
  final bool decisions;
  const OfficialSourcesPage({super.key, required this.decisions});
  Future<void> open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(decisions ? 'Resmî Karar Arama' : 'Resmî Mevzuat')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Icon(Icons.verified, size: 64, color: gold),
      const SizedBox(height: 12),
      Text(decisions ? 'Kararları yalnız resmî sistemlerden arayın.' : 'Güncel mevzuatı yalnız resmî sistemlerden açın.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
      const SizedBox(height: 22),
      if (decisions) ...[
        FilledButton.icon(onPressed: () => open('https://emsal.uyap.gov.tr/'), icon: const Icon(Icons.search), label: const Text('UYAP Emsal Karar Arama')),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => open('https://karararama.yargitay.gov.tr/'), icon: const Icon(Icons.gavel), label: const Text('Yargıtay Karar Arama')),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => open('https://karararama.danistay.gov.tr/'), icon: const Icon(Icons.account_balance), label: const Text('Danıştay Karar Arama')),
      ] else ...[
        FilledButton.icon(onPressed: () => open('https://www.mevzuat.gov.tr/'), icon: const Icon(Icons.menu_book), label: const Text('Mevzuat Bilgi Sistemi')),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => open('https://www.resmigazete.gov.tr/'), icon: const Icon(Icons.newspaper), label: const Text('Resmî Gazete')),
      ],
      const SizedBox(height: 20),
      const Card(color: Color(0xFF102B50), child: Padding(padding: EdgeInsets.all(16), child: Text('Bulduğunuz karar veya mevzuat metnini kopyalayıp Hukuk AI ekranındaki “Resmî kaynak metni” alanına yapıştırın. AI yalnız bu metne dayanarak açıklama yapar.'))),
    ]),
  );
}
