# HukukAsistan AI v0.5

Flutter tabanlı hukuk araştırma, karar arama ve dilekçe hazırlama uygulaması başlangıç projesi.

Bu sürüm; Firebase yönetici girişi, resmî UYAP/Yargıtay/Danıştay karar araması, resmî mevzuat bağlantıları ve yalnız kullanıcının verdiği resmî kaynak metnine dayanan Hukuk AI analizini içerir.

Özel lacivert-altın HukukAsistan AI uygulama simgesi eklendi.

> Uygulamadaki içerikler hukuki danışmanlık yerine geçmez. Karar ve mevzuat bilgileri resmî kaynaklardan doğrulanmalıdır.
