import 'package:flutter/material.dart';

void main() => runApp(const HukukAsistanApp());

const navy = Color(0xFF081A33);
const gold = Color(0xFFD4AF37);

class HukukAsistanApp extends StatelessWidget {
  const HukukAsistanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'HukukAsistan AI',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
          scaffoldBackgroundColor: navy,
          appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
          cardTheme: CardThemeData(color: const Color(0xFF10294D), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
          useMaterial3: true,
        ),
        home: const MainShell(),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), SimplePage(title: 'Hukuk AI', icon: Icons.auto_awesome, text: 'Hukuki sorunuzu yazın. Yanıtlar bilgilendirme amaçlıdır ve resmi kaynaklarla doğrulanmalıdır.'), SimplePage(title: 'Dosyalarım', icon: Icons.folder_copy, text: 'Dilekçelerinizi ve belgelerinizi burada yönetin.'), SimplePage(title: 'Profil', icon: Icons.person, text: 'Hesap, favoriler, bildirimler ve uygulama ayarları.')];
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('HukukAsistan AI'), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
            NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Hukuk AI'),
            NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'Dosyalar'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
          ],
        ),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('Hukuk AI', Icons.auto_awesome, 'Sorularınızı yapay zekâya sorun'),
      ('Dilekçe Oluştur', Icons.description, 'Adım adım dilekçe hazırlayın'),
      ('Yargıtay Kararları', Icons.gavel, 'Resmî karar kaynaklarında arayın'),
      ('Güncel Mevzuat', Icons.account_balance, 'Kanun ve yönetmeliklere ulaşın'),
      ('Belge Analizi', Icons.document_scanner, 'Belgenizi incelemeye hazırlayın'),
      ('Yönetici Paneli', Icons.admin_panel_settings, 'İçerik ve kullanıcı yönetimi'),
    ];
    return ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Hukuki bilgiye hızlı ve güvenilir erişim', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Araştırın, kararları inceleyin ve dilekçenizi hazırlayın.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 18),
      ...items.map((e) => Card(child: ListTile(contentPadding: const EdgeInsets.all(16), leading: CircleAvatar(backgroundColor: gold, foregroundColor: navy, child: Icon(e.$2)), title: Text(e.$1, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(e.$3), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SimplePage(title: e.$1, icon: e.$2, text: e.$3))))),
      const Padding(padding: EdgeInsets.only(top: 12), child: Text('HukukAsistan AI avukatlık hizmeti vermez. Kritik işlemlerde bir hukuk uzmanına danışın.', style: TextStyle(fontSize: 12, color: Colors.white60))),
    ]);
  }
}

class SimplePage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String text;
  const SimplePage({super.key, required this.title, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 72, color: gold), const SizedBox(height: 20), Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 12), Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: Colors.white70)), const SizedBox(height: 24), const TextField(decoration: InputDecoration(filled: true, labelText: 'Arama veya açıklama', border: OutlineInputBorder())), const SizedBox(height: 14), FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.search), label: const Text('Devam Et'))])),
      );
}
