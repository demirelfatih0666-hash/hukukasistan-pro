# HukukAsistan AI v0.2

Flutter tabanlı hukuk araştırma, karar arama ve dilekçe hazırlama uygulaması başlangıç projesi.

Bu sürüm; ana sayfa, Hukuk AI, Yargıtay kararları, mevzuat, dilekçe oluşturma, belge analizi, yönetici paneli ve profil bölümlerini içerir.

> Uygulamadaki içerikler hukuki danışmanlık yerine geçmez. Karar ve mevzuat bilgileri resmî kaynaklardan doğrulanmalıdır.
