# HukukAsistan AI v0.3

Flutter tabanlı hukuk araştırma, karar arama ve dilekçe hazırlama uygulaması başlangıç projesi.

Bu sürüm; Firebase e-posta/şifre girişi, yalnız tanımlı yönetici e-postasına açılan panel, Firebase AI Logic üzerinden çalışan Hukuk AI ve dilekçe taslağı oluşturucuyu içerir.

> Uygulamadaki içerikler hukuki danışmanlık yerine geçmez. Karar ve mevzuat bilgileri resmî kaynaklardan doğrulanmalıdır.
